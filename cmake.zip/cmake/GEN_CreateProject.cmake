# --------------------------------------------------------------------
# GEN_CreateProject.cmake
# Create project for CMake of GEN 
# --------------------------------------------------------------------

include_directories(${GEN_INCLUDES_DIR_LIST})

if(COMPILE_FOR_ANDROID)
  option(APPMODE_LIBRARY_DINAMIC_FEATURE                        "Android NativeActivity shared library"                   ON )
  option(APPMODE_LIBRARY_STATIC_FEATURE                         "Android static library"                                  OFF )
endif()

if(COMPILE_FOR_ESP32)

  # idf_component_register(SRCS "hello_world_main.c"  INCLUDE_DIRS "")

else()

  if(APPMODE_LIBRARY_STATIC_FEATURE)

    add_library(${CMAKE_PROJECT_NAME} STATIC ${GEN_SOURCES_MODULES_LIST}) 

  endif()


  if(APPMODE_LIBRARY_DINAMIC_FEATURE)

    add_library(${CMAKE_PROJECT_NAME} SHARED ${GEN_SOURCES_MODULES_LIST})

  endif()


  if(APPMODE_LIBRARY_STATIC_FEATURE OR APPMODE_LIBRARY_DINAMIC_FEATURE)

    if(COMPILE_FOR_LINUX)

      if(APPMODE_LIBRARY_STATIC_FEATURE)

        set_target_properties(${CMAKE_PROJECT_NAME} PROPERTIES OUTPUT_NAME ${CMAKE_PROJECT_NAME} ARCHIVE_OUTPUT_DIRECTORY /tmp)   # <- STATIC (.a)

      endif()


      if(APPMODE_LIBRARY_DINAMIC_FEATURE)

        set_target_properties(${CMAKE_PROJECT_NAME} PROPERTIES OUTPUT_NAME ${CMAKE_PROJECT_NAME} LIBRARY_OUTPUT_DIRECTORY /tmp)   # <- SHARED (.so)

      endif()

      add_custom_command( TARGET ${CMAKE_PROJECT_NAME} POST_BUILD
                          COMMAND ${CMAKE_COMMAND} -E echo "Copy $<TARGET_FILE:${CMAKE_PROJECT_NAME}> to ${CMAKE_BINARY_DIR}"
                          COMMAND ${CMAKE_COMMAND} -E make_directory ${CMAKE_BINARY_DIR}
                          COMMAND ${CMAKE_COMMAND} -E copy_if_different $<TARGET_FILE:${CMAKE_PROJECT_NAME}> ${CMAKE_BINARY_DIR}/$<TARGET_FILE_NAME:${CMAKE_PROJECT_NAME}>
                        )
    endif()

    if(COMPILE_FOR_ANDROID AND APPMODE_LIBRARY_DINAMIC_FEATURE)

      set_target_properties(${CMAKE_PROJECT_NAME} PROPERTIES
                            OUTPUT_NAME ${CMAKE_PROJECT_NAME}
                            LIBRARY_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR})

      include("${GEN_DIRECTORY}/Common/cmake/Main/GEN_Main_Android_BuildPackage.cmake")

    endif()

  else()  

   
    
    add_executable(${CMAKE_PROJECT_NAME} ${GEN_SOURCES_MODULES_LIST})
    
    if(APP_RESOURCE_FILE)

      set_source_files_properties(${APP_RESOURCE_FILE} PROPERTIES LANGUAGE RC)
      target_sources(${CMAKE_PROJECT_NAME} PRIVATE ${APP_RESOURCE_FILE})

      # old method
      # add_executable(${CMAKE_PROJECT_NAME} ${GEN_SOURCES_MODULES_LIST} ${APP_RESOURCE_FILE})

    endif()

  endif()


endif()


if(COMPILE_FOR_LINUX  AND (CMAKE_BUILD_TYPE STREQUAL "Debug"))  
  
  target_compile_options(${CMAKE_PROJECT_NAME} PRIVATE -g -O0 -fno-omit-frame-pointer -fno-inline)
  target_link_options   (${CMAKE_PROJECT_NAME} PRIVATE -Wl,--export-dynamic) 
    
endif()