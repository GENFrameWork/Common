# --------------------------------------------------------------------
# GEN_Main_Compiler_Windows.cmake
# Main: Windows Compiler
# --------------------------------------------------------------------


add_definitions(-D_CRT_SECURE_NO_WARNINGS)

set(CMAKE_RC_COMPILER rc.exe CACHE FILEPATH "" FORCE)
  
if(USE_CLANG_COMPILER_FEATURE)
 
  set(CMAKE_C_COMPILER   clang-cl CACHE FILEPATH "" FORCE)
  set(CMAKE_CXX_COMPILER clang-cl CACHE FILEPATH "" FORCE)


  if(COMPILE_FOR_WINDOWS_INTEL_32)

    add_compile_options(/clang:-m32)
    add_link_options(/MACHINE:X86)

  endif()


  if(COMPILE_FOR_WINDOWS_INTEL_64)

    add_compile_options(/clang:-m64)
    add_link_options(/MACHINE:X64)

  endif()


else()

  
 # set(CompilerFlags CMAKE_C_FLAGS 
 #                   CMAKE_C_FLAGS_DEBUG 
 #                   CMAKE_C_FLAGS_RELEASE 
 #                   CMAKE_C_FLAGS_MINSIZEREL 
 #                   CMAKE_C_FLAGS_RELWITHDEBINFO
 #
 #                   CMAKE_CXX_FLAGS 
 #                   CMAKE_CXX_FLAGS_DEBUG 
 #                   CMAKE_CXX_FLAGS_RELEASE 
 #                   CMAKE_CXX_FLAGS_MINSIZEREL 
 #                   CMAKE_CXX_FLAGS_RELWITHDEBINFO)
 #
 #
 #
 #               
 # foreach(CompilerFlag ${CompilerFlags})
 #
 #   if(WINDOWS_APPMODE_DINAMIC)  
 #
 #
 #
 #     string(REPLACE "/MT" "/MD" ${CompilerFlag} "${${CompilerFlag}}")
 #
 #   else()
 #
 #
 # 
 #     string(REPLACE "/MD" "/MT" ${CompilerFlag} "${${CompilerFlag}}")
 #
 #   endif()  
 #
 #
 # 
 #   set(${CompilerFlag} "${${CompilerFlag}}" CACHE STRING "msvc compiler flags"   FORCE)
 #   message(STATUS "[ GEN MSVC flags: ${CompilerFlag}:${${CompilerFlag}}")
 #
 # endforeach()
 
 
  if(WINDOWS_APPMODE_DINAMIC)

    set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreadedDLL$<$<CONFIG:Debug>:Debug>")

  else()

    set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")

  endif()

endif()